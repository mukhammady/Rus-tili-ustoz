# RusUstoz 2.0

Android ilova: o‘zbek tilida tushuntirilgan rus tili darslari.

- 10 modul va 100 ta dars
- Kundalik muloqot, ish va mijoz bilan suhbatlar
- Har darsda iboralar, o‘zbekcha tarjima, lotincha talaffuz, dialog va test
- Ruscha matnni Android Text-to-Speech orqali tinglash
- AI Ustoz sinov ekranida ruscha nutqni mikrofon orqali matnga aylantirish (telefonning speech recognition xizmatiga bog‘liq)

## Telefon orqali APK yig‘ish
GitHub Actions `RusUstoz-stage3.zip` faylini yig‘adi. Workflow hali GitHub’da ham yangilangan bo‘lishi kerak. Build natijasidagi `RusUstoz-2.0-debug-apk` artifact ZIP’ini yuklab olib, ichidagi APK’ni o‘rnating.

Eslatma: AI Ustoz hozircha haqiqiy AI serveriga ulanmagan; javob tekshiruvi oddiy kalit-so‘zlar asosida. Mikrofon Android qurilmasidagi nutqni tanish xizmatidan foydalanadi.
