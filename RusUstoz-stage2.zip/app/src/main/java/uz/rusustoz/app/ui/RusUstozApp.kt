package uz.rusustoz.app.ui

import android.speech.tts.TextToSpeech
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import androidx.compose.ui.graphics.vector.ImageVector
import uz.rusustoz.app.ui.screens.PlaceholderScreen
import java.util.Locale

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Bosh sahifa", Icons.Filled.Home),
    Lessons("lessons", "Darslar", Icons.Filled.Book),
    Teacher("teacher", "AI Ustoz", Icons.Filled.Chat),
    Words("words", "Lug‘at", Icons.Filled.Translate),
    Profile("profile", "Profil", Icons.Filled.AccountCircle),
}

private data class Phrase(val ru: String, val uz: String, val pron: String)
private data class DialogueLine(val speaker: String, val ru: String, val uz: String)
private data class Lesson(val id: String, val module: Int, val moduleTitle: String, val title: String, val goal: String, val phrases: List<Phrase>, val dialogue: List<DialogueLine>, val question: String, val answers: List<String>, val correct: Int, val explanation: String)

private val lessons = listOf(
    Lesson("m1l1",1,"Tanishuv va salomlashish","Salomlashish","Mijoz bilan suhbatni odobli boshlash",listOf(Phrase("Здравствуйте!","Assalomu alaykum! (rasmiy)","Zdrastvuyte"),Phrase("Доброе утро!","Xayrli tong!","Dobroye utro"),Phrase("Как дела?","Ishlar qalay?","Kak dela"),Phrase("Очень приятно.","Tanishganimdan xursandman.","Ochen priyatna")),listOf(DialogueLine("Siz","Здравствуйте! Чем могу помочь?","Assalomu alaykum! Sizga qanday yordam bera olaman?"),DialogueLine("Mijoz","Мне нужна вывеска для магазина.","Menga do‘kon uchun peshlavha kerak.")),"“Sizga qanday yordam bera olaman?” rus tilida qanday?",listOf("Чем могу помочь?","Сколько это стоит?","До свидания!"),0,"Чем могу помочь? — Sizga qanday yordam bera olaman?"),
    Lesson("m1l2",1,"Tanishuv va salomlashish","O‘zingizni tanishtirish","Ismingizni aytish va mijozning ismini so‘rash",listOf(Phrase("Меня зовут ...","Mening ismim ...","Menya zavut"),Phrase("А как вас зовут?","Sizning ismingiz nima? (rasmiy)","A kak vas zavut"),Phrase("Я менеджер.","Men menejerman.","Ya menedzher"),Phrase("Я вас внимательно слушаю.","Sizni diqqat bilan tinglayapman.","Ya vas vnimatelna slushayu")),listOf(DialogueLine("Siz","Здравствуйте! Меня зовут Азиз. Я менеджер.","Assalomu alaykum! Mening ismim Aziz. Men menejerman."),DialogueLine("Mijoz","Очень приятно. Меня зовут Анна.","Tanishganimdan xursandman. Mening ismim Anna.")),"“Mening ismim ...” qaysi ibora?",listOf("Как дела?","Меня зовут ...","До завтра."),1,"Меня зовут ... — Mening ismim ..."),
    Lesson("m1l3",1,"Tanishuv va salomlashish","Iltimos va rahmat","Xushmuomala iboralarni ishlatish",listOf(Phrase("Пожалуйста.","Iltimos / marhamat.","Pazhalusta"),Phrase("Спасибо большое.","Katta rahmat.","Spasiba balshoye"),Phrase("Не за что.","Arzimaydi.","Ne za chto"),Phrase("Извините, пожалуйста.","Kechirasiz, iltimos.","Izvinite, pazhalusta")),listOf(DialogueLine("Mijoz","Спасибо за консультацию.","Maslahat uchun rahmat."),DialogueLine("Siz","Пожалуйста! Если будут вопросы, обращайтесь.","Marhamat! Savollaringiz bo‘lsa, murojaat qiling.")),"“Katta rahmat” rus tilida qanday?",listOf("Спасибо большое.","Не за что.","Извините."),0,"Спасибо большое — katta rahmat."),
    Lesson("m1l4",1,"Tanishuv va salomlashish","Suhbatni yakunlash","Mijoz bilan suhbatni xushmuomala tugatish",listOf(Phrase("До свидания!","Xayr! (rasmiy)","Da svidaniya"),Phrase("Хорошего дня!","Kuningiz yaxshi o‘tsin!","Kharosheva dnya"),Phrase("Будем на связи.","Aloqada bo‘lib turamiz.","Budem na svyazi"),Phrase("Спасибо за обращение.","Murojaatingiz uchun rahmat.","Spasiba za abrasheniye")),listOf(DialogueLine("Siz","Спасибо за обращение. Будем на связи.","Murojaatingiz uchun rahmat. Aloqada bo‘lib turamiz."),DialogueLine("Mijoz","Хорошо. Хорошего дня!","Yaxshi. Kuningiz yaxshi o‘tsin!")),"“Kuningiz yaxshi o‘tsin!” rus tilida qanday?",listOf("До свидания!","Хорошего дня!","Пожалуйста."),1,"Хорошего дня! — Kuningiz yaxshi o‘tsin!"),
    Lesson("m2l1",2,"Mijoz ehtiyojini aniqlash","Nima kerakligini so‘rash","Mijozning buyurtmasini aniqlashtirish",listOf(Phrase("Что именно вам нужно?","Sizga aynan nima kerak?","Shto imenno vam nuzhna"),Phrase("Для какого помещения?","Qaysi joy uchun?","Dlya kakovo pomeshcheniya"),Phrase("Какой размер вам нужен?","Sizga qanday o‘lcham kerak?","Kakoy razmer vam nuzhen"),Phrase("У вас есть макет?","Sizda maket bormi?","U vas yest maket")),listOf(DialogueLine("Siz","Здравствуйте! Что именно вам нужно?","Assalomu alaykum! Sizga aynan nima kerak?"),DialogueLine("Mijoz","Мне нужна световая вывеска для магазина.","Menga do‘kon uchun yorug‘likli peshlavha kerak.")),"“Sizda maket bormi?” rus tilida qanday?",listOf("У вас есть макет?","Как вас зовут?","Хорошего дня!"),0,"У вас есть макет? — Sizda maket bormi?"),
    Lesson("m2l2",2,"Mijoz ehtiyojini aniqlash","O‘lcham va material","O‘lcham, material va joylashuv haqida so‘rash",listOf(Phrase("Какая ширина и высота?","Eni va balandligi qancha?","Kakaya shirina i vysota"),Phrase("Из какого материала?","Qaysi materialdan?","Iz kakovo materiala"),Phrase("Где будет установлена вывеска?","Peshlavha qayerga o‘rnatiladi?","Gde budet ustanovlena vyveska"),Phrase("Нужна подсветка?","Yoritish kerakmi?","Nuzhna podsvetka")),listOf(DialogueLine("Siz","Какая ширина и высота вывески?","Peshlavhaning eni va balandligi qancha?"),DialogueLine("Mijoz","Два метра в ширину. И нужна подсветка.","Eni ikki metr. Yoritish ham kerak.")),"“Yoritish kerakmi?” rus tilida qanday?",listOf("Нужна подсветка?","Как вас зовут?","Не за что."),0,"Нужна подсветка? — Yoritish kerakmi?"),
    Lesson("m2l3",2,"Mijoz ehtiyojini aniqlash","Narx va hisob-kitob","Narxni hisoblash va taklif yuborishni aytish",listOf(Phrase("Я сейчас рассчитаю стоимость.","Hozir narxini hisoblab beraman.","Ya seychas rasschitayu stoimost"),Phrase("Стоимость зависит от размера.","Narx o‘lchamga bog‘liq.","Stoimost zavisit ot razmera"),Phrase("Я отправлю вам расчёт.","Sizga hisob-kitobni yuboraman.","Ya otpravlyu vam raschyot"),Phrase("Вам удобно в WhatsApp или Telegram?","Sizga WhatsApp yoki Telegram qulaymi?","Vam udobna ...")),listOf(DialogueLine("Siz","Я сейчас рассчитаю стоимость и отправлю вам расчёт.","Hozir narxini hisoblab, sizga hisob-kitobni yuboraman."),DialogueLine("Mijoz","Хорошо, буду ждать.","Yaxshi, kutaman.")),"“Hozir narxini hisoblab beraman” qaysi ibora?",listOf("Я сейчас рассчитаю стоимость.","Где вы живёте?","До свидания!"),0,"Я сейчас рассчитаю стоимость — Hozir narxini hisoblab beraman."),
    Lesson("m2l4",2,"Mijoz ehtiyojini aniqlash","Muddat va keyingi qadam","Tayyorlash muddati va buyurtma jarayonini tushuntirish",listOf(Phrase("Сколько времени займёт изготовление?","Tayyorlash qancha vaqt oladi?","Skolka vremeni zaymyot izgotovleniye"),Phrase("Обычно это занимает ... дней.","Odatda bu ... kun vaqt oladi.","Obychna eta zanimayet ... dney"),Phrase("После согласования макета начнём работу.","Maket tasdiqlangach, ishni boshlaymiz.","Posle saglasovaniya maketa nachnyom rabotu"),Phrase("Я сообщу вам точный срок.","Sizga aniq muddatni ma’lum qilaman.","Ya saobshchu vam tochnyy srok")),listOf(DialogueLine("Mijoz","Когда будет готов заказ?","Buyurtma qachon tayyor bo‘ladi?"),DialogueLine("Siz","Я уточню срок и сообщу вам сегодня.","Muddatni aniqlashtirib, bugun sizga xabar beraman.")),"“Sizga aniq muddatni ma’lum qilaman” rus tilida qanday?",listOf("Я сообщу вам точный срок.","Мне нужна вывеска.","Спасибо большое."),0,"Я сообщу вам точный срок — Sizga aniq muddatni ma’lum qilaman.")
)

@Composable
fun RusUstozApp() {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route
    var selectedLessonId by remember { mutableStateOf<String?>(null) }
    val completed = remember { mutableStateListOf<String>() }
    Scaffold(bottomBar = {
        NavigationBar { Tab.entries.forEach { tab ->
            NavigationBarItem(selected = current == tab.route, onClick = {
                nav.navigate(tab.route) { popUpTo(nav.graph.findStartDestination().id) { saveState = true }; launchSingleTop = true; restoreState = true }
            }, icon = { Icon(tab.icon, contentDescription = tab.label) }, label = { Text(tab.label) })
        } }
    }) { padding ->
        NavHost(nav, startDestination = Tab.Home.route, modifier = Modifier.padding(padding)) {
            composable(Tab.Home.route) { HomeScreen(completed.size, lessons.size, onLessons = { nav.navigate(Tab.Lessons.route) }) }
            composable(Tab.Lessons.route) {
                val selected = lessons.firstOrNull { it.id == selectedLessonId }
                if (selected == null) LessonsScreen(completed, onOpen = { selectedLessonId = it })
                else LessonScreen(selected, selected.id in completed, onBack = { selectedLessonId = null }, onComplete = { if (selected.id !in completed) completed.add(selected.id) })
            }
            composable(Tab.Teacher.route) { TeacherScreen() }
            composable(Tab.Words.route) { VocabularyScreen() }
            composable(Tab.Profile.route) { ProfileScreen(completed.size, lessons.size) }
        }
    }
}

@Composable private fun HomeScreen(done: Int, total: Int, onLessons: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("RusUstoz", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Rus tilida ishonch bilan gapirishni boshlang.", style = MaterialTheme.typography.bodyLarge)
        Card { Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Sizning o‘rganish yo‘lingiz", style = MaterialTheme.typography.titleMedium)
            Text("$done / $total dars tugallangan")
            LinearProgressIndicator(progress = if (total == 0) 0f else done.toFloat()/total, modifier = Modifier.fillMaxWidth())
            Button(onClick = onLessons, modifier = Modifier.fillMaxWidth()) { Text("Darsni boshlash") }
        } }
        Text("Bugungi maqsad", style = MaterialTheme.typography.titleMedium)
        Text("Kuniga 30 daqiqa: iboralarni o‘qing, talaffuzni tinglang va kichik testni bajaring.")
        Text("Hozir mavjud: 2 modul · 8 dars · mijoz bilan muloqot", style = MaterialTheme.typography.labelLarge)
    }
}

@Composable private fun LessonsScreen(completed: List<String>, onOpen: (String) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Darslar", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text("1-modul · Tanishuv va salomlashish", style = MaterialTheme.typography.titleMedium) }
        items(lessons.filter { it.module == 1 }) { lesson -> LessonCard(lesson, lesson.id in completed, onOpen) }
        item { Spacer(Modifier.height(4.dp)); Text("2-modul · Mijoz ehtiyojini aniqlash", style = MaterialTheme.typography.titleMedium) }
        items(lessons.filter { it.module == 2 }) { lesson -> LessonCard(lesson, lesson.id in completed, onOpen) }
    }
}

@Composable private fun LessonCard(lesson: Lesson, done: Boolean, onOpen: (String) -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onOpen(lesson.id) }) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(lesson.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(lesson.goal, style = MaterialTheme.typography.bodySmall) }
        Text(if (done) "✓ Bajarildi" else "Boshlash", color = if (done) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary, style = MaterialTheme.typography.labelMedium)
    } }
}

@Composable private fun LessonScreen(lesson: Lesson, done: Boolean, onBack: () -> Unit, onComplete: () -> Unit) {
    var answer by remember(lesson.id) { mutableStateOf<Int?>(null) }
    val context = LocalContext.current
    val tts = remember { TextToSpeech(context) { status -> if (status == TextToSpeech.SUCCESS) { /* language is selected when Speak is pressed */ } } }
    DisposableEffect(tts) { onDispose { tts.stop(); tts.shutdown() } }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("‹ Orqaga", Modifier.clickable { onBack() }.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.primary) }
        item { Text("${lesson.module}-modul · ${lesson.moduleTitle}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary) }
        item { Text(lesson.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { Text(lesson.goal, style = MaterialTheme.typography.bodyLarge) }
        item { Text("Asosiy iboralar", style = MaterialTheme.typography.titleLarge) }
        items(lesson.phrases) { p -> Card { Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(p.ru, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(p.uz)
            Text("Talaffuz: ${p.pron}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            TextButton(onClick = { val result = tts.setLanguage(Locale("ru", "RU")); if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) tts.speak(p.ru, TextToSpeech.QUEUE_FLUSH, null, p.ru) }) { Text("🔊 Tinglash") }
        } } }
        item { Text("Qisqa dialog", style = MaterialTheme.typography.titleLarge) }
        items(lesson.dialogue) { line -> Card { Column(Modifier.fillMaxWidth().padding(14.dp)) { Text(line.speaker, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.secondary); Text(line.ru, fontWeight = FontWeight.SemiBold); Text(line.uz) } } }
        item { Text("O‘zingizni tekshiring", style = MaterialTheme.typography.titleLarge) }
        item { Text(lesson.question, style = MaterialTheme.typography.titleMedium) }
        items(lesson.answers.size) { index ->
            OutlinedButton(onClick = { answer = index }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (answer == index) { if (index == lesson.correct) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer } else MaterialTheme.colorScheme.surface)) { Text(lesson.answers[index]) }
        }
        if (answer != null) item { Text(if (answer == lesson.correct) "To‘g‘ri! ${lesson.explanation}" else "Yana urinib ko‘ring. ${lesson.explanation}", color = if (answer == lesson.correct) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
        item { Button(onClick = { if (answer == lesson.correct) onComplete() }, enabled = answer == lesson.correct, modifier = Modifier.fillMaxWidth()) { Text(if (done) "Dars bajarilgan ✓" else "Darsni tugatish") } }
    }
}

@Composable private fun VocabularyScreen() {
    val words = listOf("Здравствуйте!" to "Assalomu alaykum!", "Чем могу помочь?" to "Sizga qanday yordam bera olaman?", "У вас есть макет?" to "Sizda maket bormi?", "Нужна подсветка?" to "Yoritish kerakmi?", "Стоимость" to "Narx / qiymat", "Размер" to "O‘lcham", "Изготовление" to "Tayyorlash / ishlab chiqarish", "Я отправлю вам расчёт." to "Sizga hisob-kitobni yuboraman.", "Спасибо большое." to "Katta rahmat.", "Хорошего дня!" to "Kuningiz yaxshi o‘tsin!")
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Lug‘at", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text("Ishda tez-tez ishlatiladigan iboralar") }
        items(words) { (ru,uz) -> Card { Column(Modifier.fillMaxWidth().padding(14.dp)) { Text(ru, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(uz) } } }
    }
}

@Composable private fun TeacherScreen() {
    var message by remember { mutableStateOf("") }
    var sent by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("AI Ustoz", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Bu sinov rejimi. Hozircha haqiqiy AI serveriga ulanmagan.")
        Card { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ustoz: Добрый день! Чем могу помочь?", fontWeight = FontWeight.SemiBold)
            Text("Tarjimasi: Xayrli kun! Sizga qanday yordam bera olaman?")
            OutlinedTextField(value = message, onValueChange = { message = it; sent = false }, modifier = Modifier.fillMaxWidth(), label = { Text("Rus tilida javob yozing") })
            Button(onClick = { sent = true }, enabled = message.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Javobni tekshirish") }
            if (sent) Text(if (message.contains("нуж", ignoreCase = true) || message.contains("вывес", ignoreCase = true)) "Yaxshi! Buyurtma ehtiyojini ifodalashga urindingiz. To‘liq AI tekshiruvi keyingi bosqichda qo‘shiladi." else "Javob saqlandi. Sinov rejimida avtomatik AI tahlili mavjud emas.")
        } }
    }
}

@Composable private fun ProfileScreen(done: Int, total: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Profil", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("O‘quvchi")
        Text("Bajarilgan darslar: $done / $total")
        LinearProgressIndicator(progress = if (total == 0) 0f else done.toFloat()/total, modifier = Modifier.fillMaxWidth())
        Text("Maqsad: har kuni 30 daqiqa rus tilida mashq qilish.")
        Text("Eslatma: bu dastlabki versiyada dars progressi ilova ochiq turgan vaqt davomida saqlanadi. Doimiy saqlash keyingi bosqichda qo‘shiladi.", style = MaterialTheme.typography.bodySmall)
    }
}
