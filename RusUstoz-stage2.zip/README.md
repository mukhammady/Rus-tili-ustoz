# RusUstoz — 2-bosqich (dastlabki ishlaydigan darslar)

## Hozir mavjud
- Material 3 interfeys va 5 ta pastki bo‘lim.
- 2 modul, 8 ta dars: salomlashish, tanishuv, xushmuomalalik, suhbatni tugatish, mijoz ehtiyojini aniqlash, o‘lcham/material, narx va muddat.
- Ruscha ibora, o‘zbekcha tarjima, talaffuz yordami va Android TTS orqali tinglash.
- Dialoglar va har dars uchun kichik test.
- Lug‘at, oddiy progress va AI Ustozning demo ekrani.
- `app/src/main/assets/lessons.json` ichida darslarning JSON nusxasi.

## Hozircha cheklovlar
- AI Ustoz haqiqiy AI serveriga ulanmagan.
- Progress hozircha doimiy xotiraga saqlanmaydi.
- Talaffuz ovozi qurilmada ruscha TTS ovozi mavjudligiga bog‘liq.
- Ushbu muhitda Android SDK/Gradle mavjud bo‘lmagani uchun kompilyatsiya bajarilmadi.

## APK’ni telefondan GitHub orqali yig‘ish
1. GitHub’da yangi repository yarating (masalan `RusUstoz`).
2. `RusUstoz-stage2.zip` faylini repository’ning bosh papkasiga yuklang.
3. Repository’da **Add file → Create new file** ni tanlang. Fayl nomini `.github/workflows/android-apk.yml` deb yozing.
4. `android-apk.yml` nomli alohida fayldagi matnni shu faylga joylashtirib, commit qiling. Bu workflow ZIP’ni ochib, Gradle 8.7 orqali APK yig‘adi.
5. **Actions** bo‘limiga kiring. `Build RusUstoz APK` ishga tushadi.
6. Ish muvaffaqiyatli tugasa, bajarilgan run sahifasining pastidagi **Artifacts** qismidan `RusUstoz-debug-apk` ni yuklab oling.
7. Artifact ZIP’ini oching, ichidagi `.apk` faylni bosing va Android so‘rasa o‘rnatishga ruxsat bering.

Agar Actions xato bersa, qizil rangdagi xato matnini yoki logning oxirgi qismini yuboring.
