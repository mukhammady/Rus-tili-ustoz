# RusUstoz Pro — yangi alohida Android ilovasi

Bu loyiha avvalgi RusUstoz ilovasidan alohida applicationId bilan yig‘iladi.

## Dars tuzilishi
- 10 modul × 10 dars = 100 dars
- Har darsda 30 ta ibora (ruscha, o‘zbekcha tarjima, talaffuz)
- Har darsda 3 ta suhbat ssenariysi (dialog satrlari bilan)
- Har darsda 15 ta tanlash mashqi va javob izohi
- Ruscha matnni Android Text-to-Speech orqali eshitish
- Mikrofon orqali nutq tanish sinovi
- Dars bajarilganini SharedPreferences’da saqlash

## Muhim cheklov
AI Ustoz hozircha haqiqiy AI serveriga ulanmagan; u sinov rejimida. Iboralarning ayrimlari modul mavzusiga mos umumiy iboralar bilan to‘ldiriladi va keyingi tahrirda har bir darsga alohida mazmun bilan boyitilishi kerak. APK build GitHub Actions’da tekshiriladi.

## Build
Android Gradle Plugin 8.5.2, Kotlin 1.9.24, Gradle 8.7 va JDK 17.
