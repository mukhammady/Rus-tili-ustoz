# Rus Ustoz — 1-bosqich (minimal skelet)

Android Studio (Koala yoki yangiroq) → File > Open → shu papka. Gradle sinxronlanishini kuting, so'ng Run.
`gradle-wrapper.jar` kiritilmagan: Android Studio o'zi Gradle 8.7 ni yuklaydi (yoki `gradle wrapper` buyrug'i).

Tayyor: Gradle, manifest, Material 3 mavzu (oq/quyuq), pastki navigatsiya (5 bo'lim), vaqtinchalik ekranlar.
Hali yo'q: Room, DataStore, darslar JSON, AI backend, TTS/STT, testlar.
