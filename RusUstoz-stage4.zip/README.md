# RusUstoz — Stage 4

Android ilovasi: o‘zbek tilida rus tilini o‘rganish, kundalik suhbatlar va mijozlar bilan muloqot.

## Stage 4 yangilanishlari
- Darslar 10 ta modulga guruhlangan; modul kartasini bosganda uning darslari ochiladi/yopiladi.
- Umumiy va modul bo‘yicha o‘quv progressi ko‘rsatiladi.
- Bajarilgan darslar SharedPreferences orqali ilova yopilgandan keyin ham saqlanadi.
- Yangilangan och/ quyuq rejim ranglari va tipografiya.

## APK build (GitHub Actions)
1. Repo ildiziga `RusUstoz-stage4.zip` yuklang.
2. `.github/workflows/android-apk.yml` faylini yangilang; `unzip` qatorida `RusUstoz-stage4.zip` yozilishi kerak.
3. Actions → Build RusUstoz APK → Run workflow.
4. Build tugagach `RusUstoz-2.1-debug-apk` artifactini yuklab oling.

Eslatma: bu loyiha internetga ulangan haqiqiy AI serverni o‘z ichiga olmaydi; AI Ustoz sahifasidagi mavjud imkoniyatlar avvalgi versiyadagidek.
